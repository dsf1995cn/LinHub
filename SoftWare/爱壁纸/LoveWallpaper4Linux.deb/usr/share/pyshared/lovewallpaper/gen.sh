pyside-uic settings.ui -o lovewallpaper/lib/settings.py
pyside-uic newversion.ui -o lovewallpaper/lib/newversion.py    
pyside-rcc resources.qrc -o lovewallpaper/resources_rc.py
python love-wallpaper

